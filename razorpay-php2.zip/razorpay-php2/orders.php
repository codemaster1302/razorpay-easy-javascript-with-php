<?php
$name = $_GET['name'];
$email = $_GET['email'];
$url = "https://api.razorpay.com/v1/orders";
$key="rzp_test_i4eS51yCaDMPio";
$token = "whKvy1bl4x4AjioIqqiP201S";
//$rec = "KTT_".date('Y'.'m'.'d'.'H'.'i'.'s');
$rec = "KTT_".date('Ymd');
$ch_session = curl_init();
curl_setopt($ch_session, CURLOPT_URL, $url);
curl_setopt($ch_session, CURLOPT_POST, true);
curl_setopt($ch_session, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch_session, CURLOPT_USERPWD, $key.':'.$token);
curl_setopt($ch_session, CURLOPT_HTTPHEADER, array("content-type: application/json"));
$data = array('amount'=>'10000',"currency"=> "INR","receipt"=> $rec,"notes"=>array("key1"=>$name,"key2"=>$email));
curl_setopt($ch_session, CURLOPT_POSTFIELDS, json_encode($data));
$result_url = curl_exec($ch_session);
$decodeResponse = json_decode($result_url);
//connection create_function
//$sql = "insert into "

echo $decodeResponse->id;
/* echo "<br/>";
echo $result_url; */
?>