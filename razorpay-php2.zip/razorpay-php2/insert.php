<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "razorpay_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$name = isset($_POST['name'])?$_POST['name']:'';
//echo $name;die();
$email = isset($_POST['email'])?$_POST['email']:'';
$phone = isset($_POST['contact'])?$_POST['contact']:'';
$amount = isset($_POST['amount'])?$_POST['amount']:'';
$payment_id = isset($_POST['razorpay_payment_id'])?$_POST['razorpay_payment_id']:'';
$order_id = isset($_POST['razorpay_order_id'])?$_POST['razorpay_order_id']:'';
$signature = isset($_POST['razorpay_signature'])?$_POST['razorpay_signature']:'';
$payment_status = isset($_POST['payment_status'])?$_POST['payment_status']:'';
$message = addslashes(isset($_POST['message'])?$_POST['message']:'');
$created_at = date('Y-m-d');
$sql = "INSERT INTO razorpay_payment_details (name, email, phone,amount,payment_id,order_id,signature,payment_status,message,created_at)
VALUES ('$name', '$email', '$phone', '$amount', '$payment_id', '$order_id', '$signature', '$payment_status', '$message', '$created_at')";

if ($conn->query($sql) === TRUE) {
  echo 1;
} else {
  echo 0;
}

$conn->close();
?>