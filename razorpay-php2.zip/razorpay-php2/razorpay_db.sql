-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2022 at 08:47 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `razorpay_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `razorpay_payment_details`
--

CREATE TABLE `razorpay_payment_details` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `amount` varchar(50) NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `created_at` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `razorpay_payment_details`
--

INSERT INTO `razorpay_payment_details` (`id`, `name`, `email`, `phone`, `amount`, `payment_id`, `order_id`, `signature`, `payment_status`, `message`, `created_at`) VALUES
(1, 'ashish', 'ahsish@gmail.com', '9808200200', '50', 'pay_KbU3EmPCo9G5fE', 'order_KbU36jfOlwOFav', 'd832a8d502673ed95ab9bfd6f50a52101148f4d7632df37d80f2b102ca4faea9', 'Success', '', '2022-11-03'),
(2, 'sumit', 'sumit@ddd.com', '9808300300', '50', 'pay_KbU4fDGbNZk8VJ', 'order_KbU4SZGzblOzQp', '69b9dc2fc60e4fe15c47fa7322bddbeff3667369ccf0acb591abb5c0f3f71d5f', 'Success', '', '2022-11-03'),
(3, 'asdsad', 'nrdpadmin@nrdp.com', '9808200211', '50', 'pay_KbU9PGAkUqOWyu', 'order_KbU9GtUHepozUB', '5ad3802d19637702c8950b453d8301437ac12dfeca388cbc4335c6fe9e080f3f', 'Success', 'Payment Successfully', '2022-11-03'),
(4, 'hkjkhkh', 'nrdpadmin@nrdp.com', '9808200200', '50', 'pay_KbUBUO40cQDhZH', 'order_KbUBMCvtRGKp70', 'BAD_REQUEST_ERROR', 'Failed', 'failed', '2022-11-03'),
(5, 'hkjkhkh', 'nrdpadmin@nrdp.com', '9808300300', '50', 'pay_KbUHCci7E04Zx5', 'order_KbUH3dxUj1IqBQ', 'BAD_REQUEST_ERROR', 'Failed', 'Your payment didn\'t go through as it was declined by the bank. Try another payment method or contact your bank.', '2022-11-03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `razorpay_payment_details`
--
ALTER TABLE `razorpay_payment_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `razorpay_payment_details`
--
ALTER TABLE `razorpay_payment_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
