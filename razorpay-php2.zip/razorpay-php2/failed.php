<?php //include('templates/header.php'); ?>
<section class="showcase">
   <div class="container">
    <div class="text-center">
      <h1 class="display-3">Thank You!</h1>
      <p class="lead">Your payment has been received successfully.</p>
      <hr>     
      <p class="lead">
        <a class="btn btn-primary btn-sm" href="index.php" role="button">Continue to homepage</a>
      </p>
    </div>
    </div>
</section>
<br><br><br><br><br><br>
<!-- Bootstrap core JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
<?php //include('templates/footer.php');?>